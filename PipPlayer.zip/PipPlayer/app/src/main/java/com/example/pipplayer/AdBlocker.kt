package com.example.pipplayer

import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/** Простой блокировщик рекламы: чёрный список доменов + пути рекламных запросов YouTube. */
object AdBlocker {

    private val hosts = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com", "2mdn.net",
        "google-analytics.com", "adnxs.com", "adsrvr.org", "taboola.com",
        "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
        "exoclick.com", "juicyads.com", "trafficjunky.com", "adsterra.com",
        "mgid.com", "revcontent.com", "onclickads.net", "clickadu.com",
        "hilltopads.net", "adcash.com", "amazon-adsystem.com", "criteo.com",
        "criteo.net", "rubiconproject.com", "pubmatic.com", "openx.net",
        "moatads.com", "scorecardresearch.com", "serving-sys.com",
        "advertising.com", "ads.yahoo.com", "an.yandex.ru",
        "yandexadexchange.net", "awaps.yandex.net", "adfox.ru", "adriver.ru",
        "begun.ru", "marketgid.com", "adskeeper.com", "smartadserver.com",
        "casalemedia.com", "bidswitch.net", "teads.tv", "yieldmo.com",
        "tsyndicate.com", "trafficstars.com", "realsrv.com", "syndication.realsrv.com",
        "a-ads.com", "ad-maven.com", "admaven.com", "pushwhy.com", "notix.io"
    )

    private val youtubePaths = listOf("/pagead/", "/api/stats/ads", "/ptracking", "/pcs/activeview")

    fun shouldBlock(uri: Uri): Boolean {
        val host = uri.host?.lowercase() ?: return false
        for (h in hosts) {
            if (host == h || host.endsWith(".$h")) return true
        }
        if (host.endsWith("youtube.com")) {
            val path = uri.encodedPath ?: return false
            for (p in youtubePaths) {
                if (path.contains(p)) return true
            }
        }
        return false
    }

    fun empty(): WebResourceResponse =
        WebResourceResponse(
            "text/plain", "utf-8", 200, "OK",
            mapOf<String, String>(), ByteArrayInputStream(ByteArray(0))
        )
}
