package com.example.pipplayer

import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.util.Rational
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

class MainActivity : Activity() {

    private enum class Mode { YOUTUBE, WEB }

    private lateinit var webView: WebView
    private lateinit var content: View
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var searchInput: EditText
    private lateinit var autoPip: CheckBox
    private lateinit var adblockBox: CheckBox
    private lateinit var btnYoutube: Button
    private lateinit var btnWeb: Button

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var mode = Mode.YOUTUBE

    @Volatile
    private var adblockOn = true

    private lateinit var bridgeJs: String
    private lateinit var cosmeticsJs: String

    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.getStringExtra(EXTRA_CMD)) {
                CMD_NEXT -> episode(1)
                CMD_PREV -> episode(-1)
                CMD_TOGGLE -> js("window.__pipToggle && window.__pipToggle()")
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        content = findViewById(R.id.content)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        searchInput = findViewById(R.id.searchInput)
        autoPip = findViewById(R.id.autoPip)
        adblockBox = findViewById(R.id.adblockBox)
        btnYoutube = findViewById(R.id.btnYoutube)
        btnWeb = findViewById(R.id.btnWeb)
        webView = findViewById(R.id.webView)

        bridgeJs = readAsset("bridge.js")
        cosmeticsJs = readAsset("cosmetics.js")

        setupWebView()

        btnYoutube.setOnClickListener {
            mode = Mode.YOUTUBE
            updateModeUi()
            if (searchInput.text.isNullOrBlank()) webView.loadUrl("https://m.youtube.com")
            else go(searchInput.text.toString())
        }
        btnWeb.setOnClickListener {
            mode = Mode.WEB
            updateModeUi()
            if (searchInput.text.isNullOrBlank()) webView.loadUrl("https://www.google.com")
            else go(searchInput.text.toString())
        }
        searchInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_GO) {
                go(searchInput.text.toString())
                true
            } else false
        }
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener { episode(-1) }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener { episode(1) }
        findViewById<ImageButton>(R.id.btnPip).setOnClickListener { enterPip() }
        adblockBox.setOnCheckedChangeListener { _, checked ->
            adblockOn = checked
            webView.reload()
        }

        updateModeUi()

        val filter = IntentFilter(ACTION_PIP)
        ContextCompat.registerReceiver(this, pipReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)

        webView.loadUrl("https://m.youtube.com")
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        // Убираем признаки WebView, чтобы сайты вели себя как в обычном Chrome
        s.userAgentString = s.userAgentString.replace("; wv", "").replace(" Version/4.0", "")

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        // Скрипт-мост во все фреймы (в т.ч. iframe-плееры сериальных сайтов)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, bridgeJs, setOf("*"))
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                if (adblockOn && AdBlocker.shouldBlock(request.url)) return AdBlocker.empty()
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme ?: ""
                if (scheme == "http" || scheme == "https") {
                    return adblockOn && AdBlocker.shouldBlock(request.url)
                }
                // intent:, market: и прочие попытки открыть другие приложения — блокируем
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                js(bridgeJs)
                if (adblockOn) js(cosmeticsJs)
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean = false // блокируем всплывающие окна

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                showCustom(view, callback)
            }

            override fun onHideCustomView() {
                hideCustom()
            }

            override fun getDefaultVideoPoster(): Bitmap? =
                Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        }
    }

    // ---------- Поиск ----------

    private fun go(raw: String) {
        val q = raw.trim()
        if (q.isEmpty()) return
        val url = when {
            q.startsWith("http://") || q.startsWith("https://") -> q
            !q.contains(" ") && q.contains(".") -> "https://$q"
            mode == Mode.YOUTUBE -> "https://m.youtube.com/results?search_query=" + Uri.encode(q)
            else -> "https://www.google.com/search?q=" + Uri.encode(q)
        }
        webView.loadUrl(url)
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(searchInput.windowToken, 0)
        searchInput.clearFocus()
    }

    private fun updateModeUi() {
        btnYoutube.alpha = if (mode == Mode.YOUTUBE) 1f else 0.5f
        btnWeb.alpha = if (mode == Mode.WEB) 1f else 0.5f
    }

    // ---------- Серии ----------

    private fun episode(dir: Int) {
        js("window.__pipEpisode ? window.__pipEpisode($dir) : 'nobridge'") { result ->
            if (result.contains("none") || result.contains("nobridge")) {
                toast("Не нашёл кнопку или номер серии на этой странице")
            }
        }
    }

    // ---------- Картинка в картинке ----------

    private fun enterPip() {
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            toast("Это устройство не поддерживает картинку в картинке")
            return
        }
        try {
            enterPictureInPictureMode(buildPipParams())
        } catch (e: Exception) {
            toast("Не удалось включить PiP: " + e.message)
        }
    }

    private fun buildPipParams(): PictureInPictureParams {
        val actions = listOf(
            pipAction(CMD_PREV, R.drawable.ic_prev, "Предыдущая серия", 1),
            pipAction(CMD_TOGGLE, R.drawable.ic_play_pause, "Пауза / play", 2),
            pipAction(CMD_NEXT, R.drawable.ic_next, "Следующая серия", 3)
        )
        return PictureInPictureParams.Builder()
            .setAspectRatio(Rational(16, 9))
            .setActions(actions)
            .build()
    }

    private fun pipAction(cmd: String, iconRes: Int, title: String, requestCode: Int): RemoteAction {
        val intent = Intent(ACTION_PIP).setPackage(packageName).putExtra(EXTRA_CMD, cmd)
        val pi = PendingIntent.getBroadcast(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return RemoteAction(Icon.createWithResource(this, iconRes), title, title, pi)
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (autoPip.isChecked && !isInPictureInPictureMode) enterPip()
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        val vis = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        topBar.visibility = vis
        bottomBar.visibility = vis
        if (customView == null) {
            js("window.__pipApply && window.__pipApply($isInPictureInPictureMode)")
        }
    }

    // ---------- Полноэкранное видео ----------

    @Suppress("DEPRECATION")
    private fun showCustom(view: View, callback: WebChromeClient.CustomViewCallback) {
        if (customView != null) {
            callback.onCustomViewHidden()
            return
        }
        customView = view
        customCallback = callback
        fullscreenContainer.addView(
            view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        fullscreenContainer.visibility = View.VISIBLE
        content.visibility = View.GONE
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    @Suppress("DEPRECATION")
    private fun hideCustom() {
        val v = customView ?: return
        fullscreenContainer.removeView(v)
        fullscreenContainer.visibility = View.GONE
        content.visibility = View.VISIBLE
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            customView != null -> hideCustom()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(pipReceiver)
        } catch (e: Exception) {
        }
        webView.destroy()
        super.onDestroy()
    }

    // ---------- Утилиты ----------

    private fun js(code: String, callback: ((String) -> Unit)? = null) {
        webView.evaluateJavascript(code) { result -> callback?.invoke(result ?: "") }
    }

    private fun readAsset(name: String): String =
        assets.open(name).bufferedReader().use { it.readText() }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    companion object {
        private const val ACTION_PIP = "com.example.pipplayer.PIP_ACTION"
        private const val EXTRA_CMD = "cmd"
        private const val CMD_NEXT = "next"
        private const val CMD_PREV = "prev"
        private const val CMD_TOGGLE = "toggle"
    }
}
