(function () {
  if (window.__cosInit) return;
  window.__cosInit = true;

  var css =
    'ins.adsbygoogle,[id^="google_ads"],[class*="adsbygoogle"],[id*="banner_ad"],' +
    'iframe[src*="doubleclick"],iframe[src*="googlesyndication"],' +
    'ytm-promoted-sparkles-web-renderer,ytm-companion-ad-renderer,ytm-promoted-video-renderer,' +
    'ytm-statement-banner-renderer,ad-slot-renderer,ytd-ad-slot-renderer,' +
    '#player-ads,.video-ads,.ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-image-overlay' +
    '{display:none!important}';
  var st = document.createElement('style');
  st.textContent = css;
  (document.head || document.documentElement).appendChild(st);

  if (/(^|\.)youtube\.com$/.test(location.hostname)) {
    setInterval(function () {
      var v = document.querySelector('video');
      var ad = document.querySelector('.ad-showing, .ad-interrupting, .ytp-ad-player-overlay');
      if (ad && v) {
        if (!window.__adMuted) { window.__adMuted = true; window.__prevMuted = v.muted; }
        v.muted = true;
        if (isFinite(v.duration) && v.duration > 0) {
          try { v.playbackRate = 16; } catch (e) {}
          v.currentTime = v.duration;
        }
      } else if (window.__adMuted && v) {
        v.muted = window.__prevMuted;
        window.__adMuted = false;
        try { v.playbackRate = 1; } catch (e) {}
      }
      var skip = document.querySelector(
        '.ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-skip-ad-button, .ytp-ad-skip-button-container button');
      if (skip) skip.click();
    }, 400);
  }
})();
