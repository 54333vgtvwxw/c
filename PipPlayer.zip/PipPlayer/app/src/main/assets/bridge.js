(function () {
  if (window.__pipInit) return;
  window.__pipInit = true;

  var STYLE_ID = '__pip_style';

  function area(e) {
    var r = e.getBoundingClientRect();
    return r.width * r.height;
  }
  function biggest(list) {
    var best = null, a = 0;
    for (var i = 0; i < list.length; i++) {
      var s = area(list[i]);
      if (s > a) { a = s; best = list[i]; }
    }
    return best;
  }
  function forward(msg) {
    var fr = document.querySelectorAll('iframe');
    for (var i = 0; i < fr.length; i++) {
      try { fr[i].contentWindow.postMessage(msg, '*'); } catch (e) {}
    }
  }
  function clear() {
    var st = document.getElementById(STYLE_ID);
    if (st) st.remove();
    var t = document.querySelectorAll('[data-pip-target]');
    for (var i = 0; i < t.length; i++) t[i].removeAttribute('data-pip-target');
  }

  // Растягивает видео (или iframe с плеером) на всё окно, чтобы в PiP было видно только видео.
  function apply(on) {
    clear();
    if (on) {
      var v = biggest(document.querySelectorAll('video'));
      var f = biggest(document.querySelectorAll('iframe'));
      var target = null, kind = '';
      if (v && (!f || area(v) >= area(f) * 0.5)) { target = v; kind = 'video'; }
      else if (f) { target = f; kind = 'frame'; }
      if (target) {
        target.setAttribute('data-pip-target', kind);
        var st = document.createElement('style');
        st.id = STYLE_ID;
        st.textContent =
          '[data-pip-target]{position:fixed!important;top:0!important;left:0!important;' +
          'width:100vw!important;height:100vh!important;max-width:none!important;max-height:none!important;' +
          'margin:0!important;padding:0!important;border:0!important;z-index:2147483647!important;' +
          'background:#000!important;transform:none!important}' +
          '[data-pip-target=video]{object-fit:contain!important}' +
          'html,body{overflow:hidden!important}';
        (document.head || document.documentElement).appendChild(st);
      }
    }
    forward({ __pip: on });
  }

  function toggle() {
    var vids = document.querySelectorAll('video');
    for (var i = 0; i < vids.length; i++) {
      var v = vids[i];
      if (area(v) > 0 || vids.length === 1) {
        if (v.paused) { v.play(); } else { v.pause(); }
        break;
      }
    }
    forward({ __cmd: 'toggle' });
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || typeof d !== 'object') return;
    if (d.__pip !== undefined) apply(!!d.__pip);
    if (d.__cmd === 'toggle') toggle();
  });

  window.__pipApply = apply;
  window.__pipToggle = toggle;

  // ---------- Следующая / предыдущая серия ----------
  function visible(el) {
    var r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  var NEXT_SELECTORS = [
    '.ytp-next-button', 'ytm-compact-autoplay-renderer a', 'ytm-autonav-endscreen-renderer a',
    'a[rel=next]', '[aria-label*="next episode" i]', '[aria-label*="следующ" i]',
    '[title*="следующ" i]', '[title*="next ep" i]', '.next-episode', '.episode-next',
    '.btn-next', 'button.next', 'a.next', '.vjs-next-button', '#next-episode',
    '.next_episode', '[data-testid*="next" i]'
  ];
  var PREV_SELECTORS = [
    '.ytp-prev-button', 'a[rel=prev]', '[aria-label*="previous episode" i]',
    '[aria-label*="предыдущ" i]', '[title*="предыдущ" i]', '[title*="prev ep" i]',
    '.prev-episode', '.episode-prev', '.btn-prev', 'button.prev', 'a.prev',
    '.vjs-prev-button', '#prev-episode', '.prev_episode', '[data-testid*="prev" i]'
  ];
  var NEXT_TEXT = /(следующ\S*\s*(серия|эпизод|сер)|след\.?\s*сер|next\s*(episode|ep)|^далее$|^next$|^следующая$|^вперед$|^вперёд$|^»$|^›$|^>>$)/i;
  var PREV_TEXT = /(предыдущ\S*\s*(серия|эпизод)|пред\.?\s*сер|prev(ious)?\s*(episode|ep)|^prev(ious)?$|^«$|^‹$|^<<$)/i;

  function bump(str, dir) {
    var kw = /((?:серия|seriya|seria|series|episode|epizod|ep|e|part|video)[-_=\/]?)(\d+)/gi;
    var m, last = null;
    while ((m = kw.exec(str)) !== null) last = m;
    if (!last) return null;
    var n = parseInt(last[2], 10) + dir;
    if (n < 1) return null;
    var start = last.index + last[1].length;
    return str.substring(0, start) + n + str.substring(start + last[2].length);
  }

  window.__pipEpisode = function (dir) {
    var sels = dir > 0 ? NEXT_SELECTORS : PREV_SELECTORS;
    var i, el;
    for (i = 0; i < sels.length; i++) {
      try { el = document.querySelector(sels[i]); } catch (e) { el = null; }
      if (el && visible(el)) { el.click(); return 'click'; }
    }
    var re = dir > 0 ? NEXT_TEXT : PREV_TEXT;
    var items = document.querySelectorAll('a,button,[role=button]');
    for (i = 0; i < items.length; i++) {
      el = items[i];
      var t = (el.innerText || el.title || el.getAttribute('aria-label') || '').trim();
      if (t.length > 0 && t.length < 40 && re.test(t) && visible(el)) { el.click(); return 'text'; }
    }
    // запасной вариант: меняем номер серии прямо в адресе
    var cur = location.pathname + location.search;
    var nxt = bump(cur, dir);
    if (!nxt) {
      var seg = /(\d+)(?=[^\d\/]*\/?$)/.exec(location.pathname);
      if (seg) {
        var n = parseInt(seg[1], 10) + dir;
        if (n >= 1) {
          nxt = location.pathname.substring(0, seg.index) + n +
                location.pathname.substring(seg.index + seg[1].length) + location.search;
        }
      }
    }
    if (nxt && nxt !== cur) { location.href = location.origin + nxt; return 'url'; }
    return 'none';
  };
})();
