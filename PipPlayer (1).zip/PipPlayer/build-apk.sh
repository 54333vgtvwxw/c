#!/usr/bin/env bash
# Сборка APK одной командой (Linux / macOS / Termux с JDK 17).
# Нужно: java 17+, curl, unzip. Остальное (Android SDK, Gradle) скрипт скачает сам.
set -euo pipefail
cd "$(dirname "$0")"

WORK="$PWD/.build-tools"
SDK="${ANDROID_HOME:-$WORK/android-sdk}"
GRADLE_VER="8.7"
mkdir -p "$WORK" "$SDK"

for cmd in java curl unzip; do
  command -v "$cmd" >/dev/null || { echo "Не найден '$cmd'. Установи его и запусти снова."; exit 1; }
done

JV=$(java -version 2>&1 | head -1 | sed -E 's/.*"([0-9]+).*/\1/')
if [ "${JV:-0}" -lt 17 ]; then
  echo "Нужна Java 17 или новее (сейчас: $JV). Установи JDK 17: https://adoptium.net"
  exit 1
fi

case "$(uname -s)" in
  Darwin) OSNAME="mac" ;;
  *)      OSNAME="linux" ;;
esac

# 1. Android command-line tools
if [ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]; then
  echo ">> Скачиваю Android command-line tools..."
  curl -L -o "$WORK/cmdtools.zip" "https://dl.google.com/android/repository/commandlinetools-${OSNAME}-11076708_latest.zip"
  rm -rf "$WORK/cmdtmp" && mkdir -p "$WORK/cmdtmp" "$SDK/cmdline-tools"
  unzip -q "$WORK/cmdtools.zip" -d "$WORK/cmdtmp"
  rm -rf "$SDK/cmdline-tools/latest"
  mv "$WORK/cmdtmp/cmdline-tools" "$SDK/cmdline-tools/latest"
fi

SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"

# 2. Лицензии и компоненты SDK
echo ">> Принимаю лицензии и ставлю SDK (platform 34, build-tools 34)..."
set +o pipefail
yes | "$SDKM" --sdk_root="$SDK" --licenses >/dev/null
set -o pipefail
"$SDKM" --sdk_root="$SDK" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

# 3. Gradle
if [ ! -x "$WORK/gradle-$GRADLE_VER/bin/gradle" ]; then
  echo ">> Скачиваю Gradle $GRADLE_VER..."
  curl -L -o "$WORK/gradle.zip" "https://services.gradle.org/distributions/gradle-$GRADLE_VER-bin.zip"
  unzip -q "$WORK/gradle.zip" -d "$WORK"
fi

# 4. Сборка
export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
echo ">> Собираю APK..."
"$WORK/gradle-$GRADLE_VER/bin/gradle" assembleDebug --no-daemon

cp app/build/outputs/apk/debug/app-debug.apk PipPlayer.apk
echo ""
echo "ГОТОВО: $PWD/PipPlayer.apk"
echo "Перекинь файл на телефон и установи."
