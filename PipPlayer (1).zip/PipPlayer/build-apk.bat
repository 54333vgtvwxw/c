@echo off
REM Сборка APK одной командой (Windows). Нужна установленная Java 17+ (https://adoptium.net).
REM Android SDK и Gradle скрипт скачает сам.
setlocal
cd /d "%~dp0"

set "WORK=%CD%\.build-tools"
if defined ANDROID_HOME (set "SDK=%ANDROID_HOME%") else (set "SDK=%WORK%\android-sdk")
set "GRADLE_VER=8.7"
if not exist "%WORK%" mkdir "%WORK%"
if not exist "%SDK%" mkdir "%SDK%"

where java >nul 2>nul
if errorlevel 1 (
  echo Java не найдена. Установи JDK 17: https://adoptium.net
  pause
  exit /b 1
)

if not exist "%SDK%\cmdline-tools\latest\bin\sdkmanager.bat" (
  echo ^>^> Скачиваю Android command-line tools...
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip' -OutFile '%WORK%\cmdtools.zip'"
  if exist "%WORK%\cmdtmp" rmdir /s /q "%WORK%\cmdtmp"
  powershell -NoProfile -Command "Expand-Archive -Force '%WORK%\cmdtools.zip' '%WORK%\cmdtmp'"
  if not exist "%SDK%\cmdline-tools" mkdir "%SDK%\cmdline-tools"
  move "%WORK%\cmdtmp\cmdline-tools" "%SDK%\cmdline-tools\latest"
)

set "SDKM=%SDK%\cmdline-tools\latest\bin\sdkmanager.bat"

echo ^>^> Принимаю лицензии и ставлю SDK...
(for /L %%i in (1,1,40) do @echo y) | call "%SDKM%" --sdk_root="%SDK%" --licenses >nul
call "%SDKM%" --sdk_root="%SDK%" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

if not exist "%WORK%\gradle-%GRADLE_VER%\bin\gradle.bat" (
  echo ^>^> Скачиваю Gradle %GRADLE_VER%...
  powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VER%-bin.zip' -OutFile '%WORK%\gradle.zip'"
  powershell -NoProfile -Command "Expand-Archive -Force '%WORK%\gradle.zip' '%WORK%'"
)

set "ANDROID_HOME=%SDK%"
set "ANDROID_SDK_ROOT=%SDK%"
echo ^>^> Собираю APK...
call "%WORK%\gradle-%GRADLE_VER%\bin\gradle.bat" assembleDebug --no-daemon
if errorlevel 1 (
  echo Сборка не удалась. Скопируй текст ошибки выше и отправь мне.
  pause
  exit /b 1
)

copy /Y "app\build\outputs\apk\debug\app-debug.apk" "PipPlayer.apk" >nul
echo.
echo ГОТОВО: %CD%\PipPlayer.apk
echo Перекинь файл на телефон и установи.
pause
